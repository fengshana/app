package com.alipay.api;


import java.io.Serializable;

/**
 * Created by bruce on 2017/12/25.
 */
public abstract class AlipayObject implements Serializable {

	private static final long serialVersionUID = 1L;

}
