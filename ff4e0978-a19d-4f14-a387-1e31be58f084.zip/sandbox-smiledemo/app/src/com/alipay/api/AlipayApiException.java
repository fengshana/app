package com.alipay.api;


/**
 * Created by bruce on 2017/12/25.
 */
public class AlipayApiException extends Throwable {
    public AlipayApiException(Exception e) {}
}
